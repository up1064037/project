def getquery(s):
     r={}
     for x in s.split("&"):
         k=x.split("=")   
         r[k[0]]=k[1]
     return (r) 